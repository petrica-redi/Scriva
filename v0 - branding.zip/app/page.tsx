import { Navigation } from "@/components/navigation";
import { HeroSection } from "@/components/sections/hero";
import { StorySection } from "@/components/sections/story";
import { LogoSection } from "@/components/sections/logo";
import { ColorSection } from "@/components/sections/color";
import { TypographySection } from "@/components/sections/typography";
import { ComponentsSection } from "@/components/sections/components";
import { SpacingSection } from "@/components/sections/spacing";
import { VoiceSection } from "@/components/sections/voice";
import { PositioningSection } from "@/components/sections/positioning";
import { MarketSection } from "@/components/sections/market";
import { Footer } from "@/components/footer";

export default function ScrivaBrandGuidePage() {
  return (
    <main className="min-h-screen bg-white">
      <Navigation />
      <HeroSection />
      <StorySection />
      <LogoSection />
      <ColorSection />
      <TypographySection />
      <ComponentsSection />
      <SpacingSection />
      <VoiceSection />
      <PositioningSection />
      <MarketSection />
      <Footer />
    </main>
  );
}
