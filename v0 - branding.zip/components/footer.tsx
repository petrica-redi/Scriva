"use client";

import { ScrivaLogo } from "./scriva-logo";

export function Footer() {
  return (
    <footer className="bg-[#042f2e] py-20 text-center">
      <div className="max-w-6xl mx-auto px-6">
        {/* Logo */}
        <div className="flex items-center justify-center gap-4 mb-8">
          <ScrivaLogo size={48} variant="dark" />
          <span className="text-2xl font-bold text-white tracking-tight">Scriva</span>
        </div>

        {/* Tagline */}
        <p className="text-[#5eead4] text-base mb-2">
          Clinical AI for European Healthcare
        </p>
        <p className="text-sm text-[#2dd4bf]">
          scriva.doctor · GDPR Compliant · EU Data Residency
        </p>

        {/* Copyright */}
        <div className="mt-8 pt-8 border-t border-white/10">
          <p className="text-xs text-[#5eead4]/70">
            © 2026 Scriva. All rights reserved. · Brand Guidelines v1.0
          </p>
        </div>
      </div>
    </footer>
  );
}
