"use client";

import { ScrivaLogo } from "@/components/scriva-logo";
import { ChevronDown } from "lucide-react";

const heroMeta = [
  { label: "Domain", value: "scriva.doctor" },
  { label: "Market", value: "European Union" },
  { label: "Version", value: "1.0 — March 2026" },
  { label: "Regulation", value: "GDPR · EHDS" },
];

export function HeroSection() {
  return (
    <section
      id="top"
      className="min-h-screen flex flex-col justify-center items-center text-center relative overflow-hidden"
      style={{
        background: "linear-gradient(165deg, #042f2e 0%, #0c3a36 40%, #115e59 100%)",
      }}
    >
      {/* Decorative Elements */}
      <div 
        className="absolute -top-48 -right-48 w-[600px] h-[600px] rounded-full pointer-events-none"
        style={{
          background: "radial-gradient(circle, rgba(20,184,166,0.15) 0%, transparent 70%)",
        }}
      />
      <div 
        className="absolute -bottom-72 -left-48 w-[700px] h-[700px] rounded-full pointer-events-none"
        style={{
          background: "radial-gradient(circle, rgba(13,148,136,0.12) 0%, transparent 70%)",
        }}
      />

      <div className="relative z-10 px-6 max-w-4xl mx-auto">
        {/* Badge */}
        <div className="inline-flex items-center gap-3 bg-white/[0.08] border border-white/10 rounded-full px-5 py-2.5 mb-12 backdrop-blur-md">
          <span className="w-2 h-2 rounded-full bg-[#2dd4bf] animate-pulse" />
          <span className="text-xs font-medium text-[#5eead4] tracking-[0.1em] uppercase">
            Brand & Design Strategy
          </span>
        </div>

        {/* Logo */}
        <div className="mb-10 flex justify-center">
          <div className="relative">
            <div className="absolute inset-0 bg-[#14b8a6]/20 blur-3xl rounded-full scale-150" />
            <ScrivaLogo size={140} variant="dark" className="relative" />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-6xl sm:text-7xl lg:text-8xl font-extrabold tracking-[-0.04em] text-white leading-[0.95] mb-8">
          Scriva
          <br />
          <span className="bg-gradient-to-r from-[#5eead4] to-[#2dd4bf] bg-clip-text text-transparent">
            Clinical AI
          </span>
        </h1>

        {/* Subtitle */}
        <p className="text-lg sm:text-xl lg:text-2xl text-[#5eead4]/90 font-normal leading-relaxed max-w-xl mx-auto mb-14">
          Identity system and design strategy for Europe&apos;s clinical AI documentation platform.
        </p>

        {/* Meta Grid */}
        <div className="flex flex-wrap justify-center gap-x-10 gap-y-6">
          {heroMeta.map((item) => (
            <div key={item.label} className="text-center">
              <div className="text-[10px] font-semibold text-white/50 uppercase tracking-[0.15em] mb-1">
                {item.label}
              </div>
              <div className="text-sm text-[#5eead4] font-medium">
                {item.value}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll Hint */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-60 hover:opacity-100 transition-opacity">
        <span className="text-[10px] text-[#2dd4bf] uppercase tracking-[0.2em] font-medium">
          Scroll
        </span>
        <ChevronDown className="w-5 h-5 text-[#2dd4bf] animate-bounce" />
      </div>
    </section>
  );
}
