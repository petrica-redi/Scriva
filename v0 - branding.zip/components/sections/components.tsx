"use client";

import { SectionWrapper, SectionHeader, Reveal } from "@/components/section-wrapper";
import { ScrivaLogo } from "@/components/scriva-logo";
import { FileText, Clock, CheckCircle, Shield, Globe, Link, Search } from "lucide-react";

const statCards = [
  { icon: FileText, label: "Today's Consultations", value: "12", iconBg: "bg-[#f0fdfa]", iconColor: "text-[#0f766e]", valueColor: "text-[#0f766e]" },
  { icon: Clock, label: "Pending Review", value: "4", iconBg: "bg-amber-50", iconColor: "text-amber-600", valueColor: "text-amber-600" },
  { icon: CheckCircle, label: "Notes Finalised", value: "8", iconBg: "bg-emerald-50", iconColor: "text-emerald-600", valueColor: "text-emerald-600" },
];

const badges = [
  { label: "GDPR Compliant", icon: Shield, className: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  { label: "EU Data Residency", icon: Globe, className: "bg-blue-50 text-blue-700 border-blue-200" },
  { label: "ISO 27001", icon: CheckCircle, className: "bg-purple-50 text-purple-700 border-purple-200" },
  { label: "HL7 FHIR R4", icon: Link, className: "bg-[#f0fdfa] text-[#0f766e] border-[#99f6e4]" },
];

const mockupPatients = [
  { name: "Maria Ionescu", time: "09:30", status: "Completed", type: "Follow-up" },
  { name: "Stefan Marinescu", time: "10:15", status: "Completed", type: "Initial" },
  { name: "Elena Dumitrescu", time: "11:00", status: "In Progress", type: "Follow-up" },
  { name: "Alexandru Popa", time: "14:00", status: "Scheduled", type: "Initial" },
];

export function ComponentsSection() {
  return (
    <>
      <SectionWrapper id="components" variant="alt">
        <Reveal>
          <SectionHeader
            number="05"
            subtitle="UI Components"
            title="Component library."
            description="Minimal, functional, premium. Built on Shadcn UI with Tailwind — every component earns its place."
          />
        </Reveal>

        {/* Buttons */}
        <Reveal delay={100}>
          <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm mb-6">
            <h4 className="text-xs font-semibold uppercase tracking-[0.1em] text-slate-400 mb-5">
              Buttons
            </h4>
            <div className="flex flex-wrap gap-3 mb-5">
              <button className="px-6 py-3 bg-[#0f766e] text-white font-semibold text-sm rounded-xl hover:bg-[#115e59] transition-all hover:shadow-lg hover:shadow-[#0f766e]/20">
                New Consultation
              </button>
              <button className="px-6 py-3 bg-transparent text-slate-700 font-semibold text-sm rounded-xl border-2 border-slate-200 hover:border-[#14b8a6] hover:text-[#0f766e] transition-all">
                Export PDF
              </button>
              <button className="px-5 py-3 text-slate-500 font-semibold text-sm rounded-xl hover:bg-slate-100 transition-all">
                Cancel
              </button>
              <button className="px-6 py-3 bg-red-50 text-red-600 font-semibold text-sm rounded-xl border border-red-200 hover:bg-red-100 transition-all">
                Stop Recording
              </button>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <button className="px-4 py-2 bg-[#0f766e] text-white font-semibold text-xs rounded-lg">Small</button>
              <button className="px-6 py-3 bg-[#0f766e] text-white font-semibold text-sm rounded-xl">Default</button>
              <button className="px-8 py-4 bg-[#0f766e] text-white font-semibold text-base rounded-2xl">Large</button>
              <button className="px-6 py-3 bg-[#0f766e] text-white font-semibold text-sm rounded-xl opacity-40 cursor-not-allowed">Disabled</button>
            </div>
          </div>
        </Reveal>

        {/* Stat Cards */}
        <Reveal delay={200}>
          <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm mb-6">
            <h4 className="text-xs font-semibold uppercase tracking-[0.1em] text-slate-400 mb-5">
              Stat Cards
            </h4>
            <div className="grid sm:grid-cols-3 gap-4">
              {statCards.map((stat) => (
                <div 
                  key={stat.label}
                  className="bg-white border border-slate-100 rounded-2xl p-6 transition-all hover:shadow-xl hover:shadow-slate-100/50 hover:-translate-y-1"
                >
                  <div className={`w-11 h-11 ${stat.iconBg} rounded-xl flex items-center justify-center mb-4`}>
                    <stat.icon className={`w-5 h-5 ${stat.iconColor}`} />
                  </div>
                  <div className="text-xs font-medium text-slate-400 mb-1">{stat.label}</div>
                  <div className={`text-3xl font-extrabold tracking-tight ${stat.valueColor}`}>{stat.value}</div>
                </div>
              ))}
            </div>
          </div>
        </Reveal>

        {/* Badges & Status */}
        <Reveal delay={300}>
          <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm mb-6">
            <h4 className="text-xs font-semibold uppercase tracking-[0.1em] text-slate-400 mb-5">
              Badges & Status
            </h4>
            <div className="flex flex-wrap gap-3 mb-5">
              {badges.map((badge) => (
                <span 
                  key={badge.label}
                  className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold border ${badge.className}`}
                >
                  <badge.icon className="w-3.5 h-3.5" />
                  {badge.label}
                </span>
              ))}
            </div>
            <div className="flex flex-wrap gap-2">
              <span className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-50 text-emerald-700">Completed</span>
              <span className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-amber-50 text-amber-700">In Progress</span>
              <span className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 text-slate-600">Scheduled</span>
            </div>
          </div>
        </Reveal>

        {/* Inputs */}
        <Reveal delay={400}>
          <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
            <h4 className="text-xs font-semibold uppercase tracking-[0.1em] text-slate-400 mb-5">
              Inputs
            </h4>
            <div className="flex gap-3 max-w-xl">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Search patients..." 
                  className="w-full pl-11 pr-4 py-3 bg-slate-50 border-2 border-slate-200 rounded-xl text-sm outline-none focus:border-[#14b8a6] focus:ring-4 focus:ring-[#f0fdfa] transition-all"
                />
              </div>
              <button className="px-6 py-3 bg-[#0f766e] text-white font-semibold text-sm rounded-xl hover:bg-[#115e59] transition-all">
                Search
              </button>
            </div>
          </div>
        </Reveal>
      </SectionWrapper>

      {/* App Mockup */}
      <SectionWrapper>
        <Reveal>
          <SectionHeader
            number="05b"
            subtitle="Application Preview"
            title="In context."
            description="How the brand system comes together in the actual product."
          />
        </Reveal>

        <Reveal delay={100}>
          <div className="bg-slate-100 rounded-3xl p-6 shadow-2xl shadow-slate-200/50">
            {/* Browser Bar */}
            <div className="flex items-center gap-2 mb-4 pb-4 border-b border-slate-200">
              <div className="w-3 h-3 rounded-full bg-red-300" />
              <div className="w-3 h-3 rounded-full bg-amber-300" />
              <div className="w-3 h-3 rounded-full bg-emerald-300" />
            </div>

            {/* App Layout */}
            <div className="grid lg:grid-cols-[240px_1fr] gap-5 min-h-[480px]">
              {/* Sidebar */}
              <div className="hidden lg:block bg-white rounded-2xl p-5 border border-slate-200">
                <div className="flex items-center gap-3 mb-6">
                  <ScrivaLogo size={36} />
                  <div>
                    <div className="font-bold text-sm text-slate-900">Scriva</div>
                    <div className="text-[9px] font-semibold uppercase tracking-[0.14em] text-[#0d9488]">Clinical AI</div>
                  </div>
                </div>
                <nav className="space-y-1">
                  {["Dashboard", "Patients", "Consultations", "Transcripts", "Clinical Notes"].map((item, i) => (
                    <div 
                      key={item}
                      className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium ${
                        i === 0 
                          ? "bg-[#f0fdfa] text-[#0f766e]" 
                          : "text-slate-500 hover:bg-slate-50"
                      }`}
                    >
                      <div className={`w-5 h-5 rounded-md ${i === 0 ? "bg-[#99f6e4]" : "bg-slate-100"}`} />
                      {item}
                    </div>
                  ))}
                  <div className="pt-6">
                    <div className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-500 hover:bg-slate-50">
                      <div className="w-5 h-5 rounded-md bg-slate-100" />
                      Settings
                    </div>
                  </div>
                </nav>
              </div>

              {/* Main Content */}
              <div className="bg-white rounded-2xl p-6 border border-slate-200">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-bold text-slate-900">Good morning, Dr. Popescu</h3>
                  <button className="px-4 py-2 bg-[#0f766e] text-white text-xs font-semibold rounded-lg">
                    + New Consultation
                  </button>
                </div>

                {/* Stats Row */}
                <div className="grid grid-cols-3 gap-3 mb-6">
                  <div className="bg-slate-50 rounded-xl p-4">
                    <div className="text-2xl font-extrabold text-[#0f766e]">12</div>
                    <div className="text-[10px] text-slate-400 font-medium">Today</div>
                  </div>
                  <div className="bg-slate-50 rounded-xl p-4">
                    <div className="text-2xl font-extrabold text-[#0f766e]">4</div>
                    <div className="text-[10px] text-slate-400 font-medium">Pending</div>
                  </div>
                  <div className="bg-slate-50 rounded-xl p-4">
                    <div className="text-2xl font-extrabold text-[#0f766e]">89%</div>
                    <div className="text-[10px] text-slate-400 font-medium">AI Accuracy</div>
                  </div>
                </div>

                {/* Table */}
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-slate-100">
                        <th className="text-left text-[10px] font-semibold uppercase tracking-wider text-slate-400 pb-3">Patient</th>
                        <th className="text-left text-[10px] font-semibold uppercase tracking-wider text-slate-400 pb-3">Time</th>
                        <th className="text-left text-[10px] font-semibold uppercase tracking-wider text-slate-400 pb-3">Status</th>
                        <th className="text-left text-[10px] font-semibold uppercase tracking-wider text-slate-400 pb-3">Type</th>
                      </tr>
                    </thead>
                    <tbody>
                      {mockupPatients.map((patient) => (
                        <tr key={patient.name} className="border-b border-slate-50">
                          <td className="py-3 text-sm font-semibold text-slate-900">{patient.name}</td>
                          <td className="py-3 text-sm text-slate-500">{patient.time}</td>
                          <td className="py-3">
                            <span className={`px-2 py-1 rounded text-[10px] font-semibold ${
                              patient.status === "Completed" ? "bg-emerald-50 text-emerald-700" :
                              patient.status === "In Progress" ? "bg-amber-50 text-amber-700" :
                              "bg-slate-100 text-slate-600"
                            }`}>
                              {patient.status}
                            </span>
                          </td>
                          <td className="py-3 text-sm text-slate-500">{patient.type}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </SectionWrapper>
    </>
  );
}
