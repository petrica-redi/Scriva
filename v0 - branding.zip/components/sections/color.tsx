"use client";

import { useState } from "react";
import { SectionWrapper, SectionHeader, Reveal } from "@/components/section-wrapper";
import { cn } from "@/lib/utils";
import { Check, Copy } from "lucide-react";

const primaryColors = [
  { name: "Brand Primary", hex: "#0f766e", role: "Buttons, nav active, primary actions", textLight: true },
  { name: "Brand Dark", hex: "#042f2e", role: "Hero sections, footer, dark surfaces", textLight: true },
  { name: "Brand Light", hex: "#f0fdfa", role: "Backgrounds, active states, highlights", textLight: false },
];

const tealScale = [
  { name: "50", hex: "#f0fdfa", textLight: false },
  { name: "100", hex: "#ccfbf1", textLight: false },
  { name: "200", hex: "#99f6e4", textLight: false },
  { name: "300", hex: "#5eead4", textLight: false },
  { name: "400", hex: "#2dd4bf", textLight: true },
  { name: "500", hex: "#14b8a6", textLight: true },
  { name: "600", hex: "#0d9488", textLight: true },
  { name: "700", hex: "#0f766e", textLight: true },
  { name: "800", hex: "#115e59", textLight: true },
  { name: "900", hex: "#134e4a", textLight: true },
  { name: "950", hex: "#042f2e", textLight: true },
];

const semanticColors = [
  { name: "Text", hex: "#0f172a" },
  { name: "Success", hex: "#059669" },
  { name: "Warning", hex: "#d97706" },
  { name: "Danger", hex: "#dc2626" },
  { name: "Border", hex: "#e2e8f0" },
];

export function ColorSection() {
  const [copiedColor, setCopiedColor] = useState<string | null>(null);

  const copyToClipboard = (hex: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedColor(hex);
    setTimeout(() => setCopiedColor(null), 1500);
  };

  return (
    <SectionWrapper id="color" variant="alt">
      <Reveal>
        <SectionHeader
          number="03"
          subtitle="Color Palette"
          title="Teal. The colour<br/>of medical trust."
          description="Used by the NHS, EU Health Commission, and Europe's leading health platforms. Teal communicates competence without coldness."
        />
      </Reveal>

      {/* Primary Colors */}
      <Reveal delay={100}>
        <div className="grid md:grid-cols-3 gap-4 mb-12">
          {primaryColors.map((color) => (
            <button
              key={color.hex}
              onClick={() => copyToClipboard(color.hex)}
              className="group relative rounded-2xl p-7 min-h-[200px] flex flex-col justify-end text-left transition-all duration-200 hover:scale-[1.02] hover:shadow-xl"
              style={{ backgroundColor: color.hex }}
            >
              <div className={cn(
                "absolute top-4 right-4 w-8 h-8 rounded-lg flex items-center justify-center transition-all",
                copiedColor === color.hex 
                  ? "bg-white/20" 
                  : "bg-white/10 opacity-0 group-hover:opacity-100"
              )}>
                {copiedColor === color.hex ? (
                  <Check className={cn("w-4 h-4", color.textLight ? "text-white" : "text-slate-800")} />
                ) : (
                  <Copy className={cn("w-4 h-4", color.textLight ? "text-white" : "text-slate-800")} />
                )}
              </div>
              <div className={cn("font-bold text-base", color.textLight ? "text-white" : "text-[#134e4a]")}>
                {color.name}
              </div>
              <div className={cn("font-mono text-sm mt-1", color.textLight ? "text-white/80" : "text-[#134e4a]/80")}>
                {color.hex}
              </div>
              <div className={cn("text-xs mt-2 leading-relaxed", color.textLight ? "text-white/70" : "text-[#134e4a]/70")}>
                {color.role}
              </div>
            </button>
          ))}
        </div>
      </Reveal>

      {/* Teal Scale */}
      <Reveal delay={200}>
        <h4 className="text-xs font-semibold uppercase tracking-[0.1em] text-slate-400 mb-3">
          Full Teal Scale <span className="font-normal">— click to copy</span>
        </h4>
        <div className="flex h-20 rounded-2xl overflow-hidden mb-12">
          {tealScale.map((color) => (
            <button
              key={color.hex}
              onClick={() => copyToClipboard(color.hex)}
              className="flex-1 relative group transition-all duration-300 hover:flex-[1.8] focus:flex-[1.8]"
              style={{ backgroundColor: color.hex }}
            >
              <span className={cn(
                "absolute bottom-2 left-1/2 -translate-x-1/2 text-[9px] font-mono font-medium whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity",
                color.textLight ? "text-white" : "text-[#134e4a]"
              )}>
                {copiedColor === color.hex ? "Copied!" : color.hex}
              </span>
            </button>
          ))}
        </div>
      </Reveal>

      {/* Semantic Colors */}
      <Reveal delay={300}>
        <h4 className="text-xs font-semibold uppercase tracking-[0.1em] text-slate-400 mb-3">
          Semantic Colours
        </h4>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
          {semanticColors.map((color) => (
            <button
              key={color.hex}
              onClick={() => copyToClipboard(color.hex)}
              className="group flex items-center gap-3 p-4 bg-white border border-slate-200 rounded-xl transition-all hover:border-[#14b8a6] hover:shadow-md"
            >
              <div 
                className="w-5 h-5 rounded-md flex-shrink-0"
                style={{ 
                  backgroundColor: color.hex,
                  border: color.hex === "#e2e8f0" ? "1px solid #cbd5e1" : "none"
                }}
              />
              <div className="text-left min-w-0">
                <div className="text-xs font-semibold text-slate-700 truncate">{color.name}</div>
                <div className="text-[10px] font-mono text-slate-400 group-hover:text-[#0f766e] transition-colors">
                  {copiedColor === color.hex ? "Copied!" : color.hex}
                </div>
              </div>
            </button>
          ))}
        </div>
      </Reveal>
    </SectionWrapper>
  );
}
