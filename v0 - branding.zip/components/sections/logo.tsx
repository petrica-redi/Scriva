"use client";

import { SectionWrapper, SectionHeader, Reveal } from "@/components/section-wrapper";
import { ScrivaLogo, ScrivaWordmark } from "@/components/scriva-logo";

const faviconSizes = [16, 32, 64, 128];

export function LogoSection() {
  return (
    <SectionWrapper id="logo">
      <Reveal>
        <SectionHeader
          number="02"
          subtitle="Logo System"
          title="The mark."
          description="Three elements of clinical AI transcription — document, microphone, stethoscope — unified in a rounded square. Paired with the Scriva wordmark in Inter 700."
        />
      </Reveal>

      {/* Logo Showcase */}
      <Reveal delay={100}>
        <div className="grid md:grid-cols-2 gap-6 mb-12">
          {/* Light Version */}
          <div className="relative bg-white border border-slate-200 rounded-3xl p-14 flex items-center justify-center min-h-[260px] shadow-sm">
            <span className="absolute top-5 left-6 text-[10px] font-semibold uppercase tracking-[0.12em] text-slate-400">
              Light
            </span>
            <div className="flex items-center gap-5">
              <ScrivaLogo size={56} variant="light" />
              <ScrivaWordmark variant="light" />
            </div>
          </div>

          {/* Dark Version */}
          <div className="relative bg-[#042f2e] rounded-3xl p-14 flex items-center justify-center min-h-[260px]">
            <span className="absolute top-5 left-6 text-[10px] font-semibold uppercase tracking-[0.12em] text-[#2dd4bf]">
              Dark
            </span>
            <div className="flex items-center gap-5">
              <ScrivaLogo size={56} variant="dark" />
              <ScrivaWordmark variant="dark" />
            </div>
          </div>
        </div>
      </Reveal>

      {/* Favicon Strip */}
      <Reveal delay={200}>
        <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <h4 className="text-xs font-semibold uppercase tracking-[0.1em] text-slate-400">
              Favicon & App Icon
            </h4>
            <div className="flex items-end gap-8">
              {faviconSizes.map((size) => (
                <div key={size} className="flex flex-col items-center gap-3">
                  <ScrivaLogo size={size} />
                  <span className="text-xs text-slate-400 font-medium">{size}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Reveal>

      {/* Clear Space */}
      <Reveal delay={300}>
        <div className="mt-12 bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
          <h4 className="text-sm font-semibold text-slate-900 mb-2">Clear Space</h4>
          <p className="text-sm text-slate-500 mb-8">
            Minimum clear space around the logo equals the width of the stethoscope disc element. 
            Never crowd the logo with other elements.
          </p>
          <div className="relative flex items-center justify-center py-12 bg-slate-50 rounded-2xl">
            {/* Guide Lines */}
            <div className="absolute inset-y-6 left-[25%] right-[25%] border-2 border-dashed border-[#5eead4] rounded-lg pointer-events-none" />
            <div className="flex items-center gap-4 relative">
              <ScrivaLogo size={48} />
              <div>
                <div className="text-xl font-bold tracking-tight text-[#134e4a]">Scriva</div>
                <div className="text-[9px] font-semibold uppercase tracking-[0.14em] text-[#0d9488]">
                  Clinical AI
                </div>
              </div>
            </div>
          </div>
        </div>
      </Reveal>
    </SectionWrapper>
  );
}
