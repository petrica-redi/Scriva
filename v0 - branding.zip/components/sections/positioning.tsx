"use client";

import { SectionWrapper, SectionHeader, Reveal } from "@/components/section-wrapper";
import { Shield, Lock, Globe } from "lucide-react";

const positioningCards = [
  {
    icon: Shield,
    title: "GDPR Native",
    description: "Data protection by design and by default. Consent management, right to erasure, data portability — built in from day one.",
  },
  {
    icon: Lock,
    title: "EHDS Ready",
    description: "Aligned with the European Health Data Space regulation (entered force March 2025). Primary and secondary use of health data.",
  },
  {
    icon: Globe,
    title: "EU Data Residency",
    description: "All patient data processed and stored within EU borders. No transatlantic data transfers. No Schrems III risk.",
  },
];

const standards = [
  "ICD-10 Diagnostic Coding",
  "SNOMED CT Clinical Terms",
  "HL7 FHIR R4 Interop",
  "openEHR Data Models",
  "EU AI Act Compliant",
  "ISO 27001 InfoSec",
];

export function PositioningSection() {
  return (
    <SectionWrapper id="positioning" variant="dark">
      <Reveal>
        <SectionHeader
          number="08"
          subtitle="EU Regulatory Positioning"
          title="Built GDPR-native.<br/>Not retrofitted."
          description="This is the core brand differentiator. Every US competitor bolted on EU compliance. Scriva was born compliant."
          dark
        />
      </Reveal>

      {/* Positioning Cards */}
      <Reveal delay={100}>
        <div className="grid md:grid-cols-3 gap-5 mb-12">
          {positioningCards.map((card) => (
            <div 
              key={card.title}
              className="bg-white/[0.06] border border-white/10 rounded-3xl p-8 backdrop-blur-sm hover:bg-white/[0.08] transition-colors"
            >
              <div className="mb-5">
                <card.icon className="w-8 h-8 text-[#2dd4bf]" />
              </div>
              <h4 className="text-lg font-bold text-white mb-3">{card.title}</h4>
              <p className="text-sm text-[#5eead4] leading-relaxed">{card.description}</p>
            </div>
          ))}
        </div>
      </Reveal>

      {/* Standards */}
      <Reveal delay={200}>
        <div className="bg-white/[0.04] border border-white/10 rounded-2xl p-8">
          <h4 className="text-sm font-semibold text-[#2dd4bf] uppercase tracking-wider mb-5">
            Supported Standards
          </h4>
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
            {standards.map((standard) => (
              <div 
                key={standard}
                className="flex items-center gap-3 px-4 py-3 bg-white/[0.04] rounded-xl text-sm text-[#99f6e4] font-medium"
              >
                <div className="w-2 h-2 rounded-full bg-[#14b8a6] flex-shrink-0" />
                {standard}
              </div>
            ))}
          </div>
        </div>
      </Reveal>
    </SectionWrapper>
  );
}
