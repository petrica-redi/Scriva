"use client";

import { SectionWrapper, SectionHeader, Reveal } from "@/components/section-wrapper";

const spacingTokens = [
  { token: "xs", value: "4px", usage: "Icon gaps, inline spacing", width: 4 },
  { token: "sm", value: "8px", usage: "Tight padding, badge gaps", width: 16 },
  { token: "md", value: "16px", usage: "Card padding, form gaps", width: 48 },
  { token: "lg", value: "24px", usage: "Section padding, card gaps", width: 80 },
  { token: "xl", value: "32px", usage: "Page margins, major gaps", width: 112 },
  { token: "2xl", value: "48px", usage: "Section spacing", width: 160 },
];

const radiusTokens = [
  { value: "6px", use: "Tags, chips" },
  { value: "10px", use: "Inputs" },
  { value: "12px", use: "Buttons" },
  { value: "16px", use: "Cards" },
  { value: "20px", use: "Panels" },
];

export function SpacingSection() {
  return (
    <SectionWrapper id="spacing" variant="alt">
      <Reveal>
        <SectionHeader
          number="06"
          subtitle="Spacing & Radius"
          title="Layout foundations."
          description="Consistent spacing and radii create a cohesive, premium feel across every screen."
        />
      </Reveal>

      {/* Spacing Table */}
      <Reveal delay={100}>
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm mb-10">
          <table className="w-full">
            <thead>
              <tr className="bg-slate-50">
                <th className="text-left text-xs font-semibold uppercase tracking-wider text-slate-400 p-5">Token</th>
                <th className="text-left text-xs font-semibold uppercase tracking-wider text-slate-400 p-5">Value</th>
                <th className="text-left text-xs font-semibold uppercase tracking-wider text-slate-400 p-5">Usage</th>
                <th className="text-left text-xs font-semibold uppercase tracking-wider text-slate-400 p-5 w-48">Scale</th>
              </tr>
            </thead>
            <tbody>
              {spacingTokens.map((token) => (
                <tr key={token.token} className="border-t border-slate-100">
                  <td className="p-5 font-semibold text-sm text-slate-900">{token.token}</td>
                  <td className="p-5 font-mono text-sm text-[#0f766e]">{token.value}</td>
                  <td className="p-5 text-sm text-slate-500">{token.usage}</td>
                  <td className="p-5">
                    <div 
                      className="h-2 bg-[#99f6e4] rounded"
                      style={{ width: token.width }}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Reveal>

      {/* Radius Demos */}
      <Reveal delay={200}>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
          {radiusTokens.map((radius) => (
            <div 
              key={radius.value}
              className="bg-white border border-slate-200 rounded-2xl p-5 text-center"
            >
              <div 
                className="w-16 h-16 mx-auto mb-4 bg-[#f0fdfa] border-2 border-[#2dd4bf]"
                style={{ borderRadius: radius.value }}
              />
              <div className="text-sm font-bold text-slate-900">{radius.value}</div>
              <div className="text-xs text-slate-400">{radius.use}</div>
            </div>
          ))}
        </div>
      </Reveal>
    </SectionWrapper>
  );
}
