"use client";

import { SectionWrapper, SectionHeader, Reveal } from "@/components/section-wrapper";
import { Check, Minus } from "lucide-react";

const marketStats = [
  { value: "$143B", label: "EU Health-Tech AI by 2033" },
  { value: "37.9%", label: "CAGR 2024–2033" },
  { value: "27", label: "EU Member States" },
  { value: "2031", label: "EHDS Full Implementation" },
];

const timeline = [
  {
    date: "March 2025",
    title: "EHDS Regulation Enters Force",
    description: "Official publication in the EU Official Journal. Member states begin national transposition.",
  },
  {
    date: "2026–2027",
    title: "Primary Use Implementation",
    description: "Patient access to health data across borders. EHR interoperability standards mandated.",
  },
  {
    date: "2028–2029",
    title: "Secondary Use Framework",
    description: "Health data access bodies established. Research and innovation data sharing enabled.",
  },
  {
    date: "2031",
    title: "Full Implementation",
    description: "Complete cross-border health data infrastructure operational across all member states.",
  },
];

const comparison = [
  { feature: "GDPR Native", scriva: "Built-in", competitor: "Retrofitted" },
  { feature: "EHDS Ready", scriva: "Yes", competitor: "No" },
  { feature: "EU Data Residency", scriva: "Guaranteed", competitor: "Optional" },
  { feature: "EU Languages", scriva: "24 official", competitor: "English first" },
  { feature: "AI Fallback", scriva: "Triple redundancy", competitor: "Single provider" },
  { feature: "Pricing Model", scriva: "Per-clinician", competitor: "Per-encounter" },
];

export function MarketSection() {
  return (
    <SectionWrapper id="market">
      <Reveal>
        <SectionHeader
          number="09"
          subtitle="Market Context"
          title="The opportunity."
          description="EU health-tech AI is projected to reach $143B by 2033, and EHDS creates a regulatory moat for EU-native platforms."
        />
      </Reveal>

      {/* Market Stats */}
      <Reveal delay={100}>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-16">
          {marketStats.map((stat) => (
            <div 
              key={stat.label}
              className="text-center bg-white border border-slate-200 rounded-2xl py-8 px-6 shadow-sm"
            >
              <div className="text-3xl md:text-4xl font-extrabold tracking-tight text-[#0f766e] mb-1">
                {stat.value}
              </div>
              <div className="text-xs text-slate-500 leading-snug">{stat.label}</div>
            </div>
          ))}
        </div>
      </Reveal>

      <div className="grid lg:grid-cols-2 gap-10">
        {/* Timeline */}
        <Reveal delay={200}>
          <div>
            <h3 className="text-xl font-bold text-slate-900 mb-8 tracking-tight">EHDS Timeline</h3>
            <div className="relative pl-8">
              {/* Line */}
              <div className="absolute left-[7px] top-0 bottom-0 w-0.5 bg-slate-200" />
              
              <div className="space-y-8">
                {timeline.map((item, index) => (
                  <div key={item.date} className="relative">
                    {/* Dot */}
                    <div className="absolute -left-8 top-1.5 w-4 h-4 rounded-full bg-[#14b8a6] border-4 border-[#f0fdfa]" />
                    
                    <div className="text-xs font-medium text-slate-400 mb-1">{item.date}</div>
                    <h4 className="text-sm font-bold text-slate-900 mb-1">{item.title}</h4>
                    <p className="text-sm text-slate-500 leading-relaxed">{item.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Reveal>

        {/* Comparison Table */}
        <Reveal delay={300}>
          <div>
            <h3 className="text-xl font-bold text-slate-900 mb-8 tracking-tight">Competitive Positioning</h3>
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
              <table className="w-full text-sm">
                <thead>
                  <tr>
                    <th className="text-left p-4 text-xs font-semibold uppercase tracking-wider text-slate-400 border-b-2 border-slate-100">
                      Feature
                    </th>
                    <th className="text-center p-4 text-xs font-semibold uppercase tracking-wider text-[#0f766e] border-b-2 border-[#ccfbf1] bg-[#f0fdfa]/50">
                      Scriva
                    </th>
                    <th className="text-center p-4 text-xs font-semibold uppercase tracking-wider text-slate-400 border-b-2 border-slate-100">
                      US Competitors
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {comparison.map((row, index) => (
                    <tr key={row.feature} className={index < comparison.length - 1 ? "border-b border-slate-100" : ""}>
                      <td className="p-4 text-slate-700">{row.feature}</td>
                      <td className="p-4 text-center font-semibold text-[#0f766e] bg-[#f0fdfa]/30">
                        <span className="inline-flex items-center gap-1.5">
                          <Check className="w-4 h-4" />
                          {row.scriva}
                        </span>
                      </td>
                      <td className="p-4 text-center text-slate-400">
                        <span className="inline-flex items-center gap-1.5">
                          <Minus className="w-4 h-4" />
                          {row.competitor}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </Reveal>
      </div>
    </SectionWrapper>
  );
}
