"use client";

import { SectionWrapper, SectionHeader, Reveal } from "@/components/section-wrapper";
import { ScrivaLogo } from "@/components/scriva-logo";
import { Shield, Clock, Target, Globe } from "lucide-react";

const values = [
  {
    icon: Shield,
    title: "Trust",
    description: "GDPR-native. EU data residency. Doctors trust us with their most sensitive data.",
    color: "bg-[#f0fdfa]",
    iconColor: "text-[#0f766e]",
  },
  {
    icon: Clock,
    title: "Clarity",
    description: "No jargon. No clutter. Every screen understood in two seconds.",
    color: "bg-blue-50",
    iconColor: "text-blue-600",
  },
  {
    icon: Target,
    title: "Precision",
    description: "Medical-grade accuracy. Every word matters. Every transcript is verifiable.",
    color: "bg-purple-50",
    iconColor: "text-purple-600",
  },
  {
    icon: Globe,
    title: "European",
    description: "Built for EU regulations, languages, and healthcare workflows from day one.",
    color: "bg-amber-50",
    iconColor: "text-amber-600",
  },
];

export function StorySection() {
  return (
    <>
      <SectionWrapper id="story">
        <Reveal>
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Visual */}
            <div className="relative aspect-[4/3] bg-gradient-to-br from-[#f0fdfa] to-[#ccfbf1] rounded-3xl flex items-center justify-center overflow-hidden group">
              <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAwIDEwIEwgNDAgMTAgTSAxMCAwIEwgMTAgNDAgTSAwIDIwIEwgNDAgMjAgTSAyMCAwIEwgMjAgNDAgTSAwIDMwIEwgNDAgMzAgTSAzMCAwIEwgMzAgNDAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzBmNzY2ZSIgc3Ryb2tlLW9wYWNpdHk9IjAuMDUiIHN0cm9rZS13aWR0aD0iMSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNncmlkKSIvPjwvc3ZnPg==')] opacity-60" />
              <div className="flex items-center gap-6 relative transition-transform duration-500 group-hover:scale-105">
                <ScrivaLogo size={80} />
                <span className="text-5xl font-extrabold tracking-[-0.03em] text-[#134e4a]">
                  Scriva
                </span>
              </div>
            </div>

            {/* Content */}
            <div>
              <SectionHeader
                number="01"
                subtitle="Brand Story"
                title="Voice becomes<br/>documentation."
              />
              <div className="space-y-5 text-base text-slate-600 leading-relaxed">
                <p>
                  <strong className="text-slate-900">Scriva</strong> comes from the Latin{" "}
                  <em>scriba</em> — the trusted scribe who recorded proceedings with precision and discretion. 
                  Across Europe the root resonates: <em>scrivere</em> (IT), <em>escrever</em> (PT), <em>escribir</em> (ES).
                </p>
                <blockquote className="text-[#0f766e] font-semibold italic border-l-4 border-[#14b8a6] pl-5 py-1 my-6">
                  &ldquo;The doctor speaks. Scriva writes.&rdquo;
                </blockquote>
                <p>
                  We exist to give European clinicians their time back. Every consultation recorded, 
                  every clinical note generated — with AI that&apos;s GDPR-native, not US-first with EU compliance bolted on.
                </p>
                <p>
                  The mark combines three elements of the workflow: a <strong>document</strong> (the output), 
                  a <strong>microphone</strong> (the input), and a <strong>stethoscope disc</strong> (the medical context).
                </p>
              </div>
            </div>
          </div>
        </Reveal>
      </SectionWrapper>

      {/* Values Section */}
      <SectionWrapper variant="alt">
        <Reveal>
          <SectionHeader
            number="01b"
            subtitle="Brand Values"
            title="Four principles."
            description="Every design and product decision flows from these."
          />
        </Reveal>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {values.map((value, index) => (
            <Reveal key={value.title} delay={index * 100}>
              <div className="bg-white rounded-2xl border border-slate-100 p-7 text-center transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-slate-100/50">
                <div className={`w-14 h-14 ${value.color} rounded-xl flex items-center justify-center mx-auto mb-5`}>
                  <value.icon className={`w-6 h-6 ${value.iconColor}`} />
                </div>
                <h4 className="text-lg font-bold text-slate-900 mb-2">{value.title}</h4>
                <p className="text-sm text-slate-500 leading-relaxed">{value.description}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </SectionWrapper>
    </>
  );
}
