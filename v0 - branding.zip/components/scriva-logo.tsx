"use client";

import { cn } from "@/lib/utils";

interface ScrivaLogoProps {
  size?: number;
  variant?: "light" | "dark";
  className?: string;
}

export function ScrivaLogo({ size = 72, variant = "light", className }: ScrivaLogoProps) {
  const bgColor = variant === "light" ? "#0f766e" : "#14b8a6";
  const docColor = variant === "light" ? "#fff" : "#042f2e";
  const docOpacity = variant === "light" ? 0.95 : 0.85;
  const lineColor = "#0d9488";
  const innerCircle = variant === "light" ? "#0f766e" : "#14b8a6";

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 72 72"
      fill="none"
      className={cn("flex-shrink-0", className)}
    >
      {/* Background */}
      <rect x="4" y="4" width="64" height="64" rx="16" fill={bgColor} />
      
      {/* Document */}
      <rect x="12" y="18" width="22" height="28" rx="3" fill={docColor} opacity={docOpacity} />
      <line x1="16" y1="26" x2="30" y2="26" stroke={lineColor} strokeWidth="1.5" strokeLinecap="round" opacity="0.5" />
      <line x1="16" y1="30" x2="27" y2="30" stroke={lineColor} strokeWidth="1.5" strokeLinecap="round" opacity="0.5" />
      <line x1="16" y1="34" x2="24" y2="34" stroke={lineColor} strokeWidth="1.5" strokeLinecap="round" opacity="0.5" />
      <line x1="16" y1="38" x2="28" y2="38" stroke={lineColor} strokeWidth="1.5" strokeLinecap="round" opacity="0.5" />
      
      {/* Microphone */}
      <rect x="42" y="14" width="12" height="18" rx="6" fill={docColor} opacity={docOpacity} />
      <path d="M42 27 Q42 35 48 35 Q54 35 54 27" stroke={docColor} strokeWidth="2" strokeLinecap="round" fill="none" opacity="0.7" />
      <line x1="48" y1="35" x2="48" y2="40" stroke={docColor} strokeWidth="2" strokeLinecap="round" opacity="0.7" />
      <line x1="44" y1="40" x2="52" y2="40" stroke={docColor} strokeWidth="2" strokeLinecap="round" opacity="0.7" />
      
      {/* Stethoscope */}
      <circle cx="48" cy="54" r="9" fill={docColor} opacity={docOpacity} />
      <circle cx="48" cy="54" r="5.5" fill={innerCircle} />
      <circle cx="48" cy="54" r="2.5" fill={docColor} opacity="0.8" />
    </svg>
  );
}

export function ScrivaWordmark({ 
  variant = "light", 
  showSubtitle = true,
  size = "default" 
}: { 
  variant?: "light" | "dark";
  showSubtitle?: boolean;
  size?: "small" | "default" | "large";
}) {
  const textColor = variant === "light" ? "text-[#134e4a]" : "text-white";
  const subtitleColor = variant === "light" ? "text-[#0d9488]" : "text-[#5eead4]";
  
  const sizes = {
    small: { name: "text-lg", subtitle: "text-[8px]" },
    default: { name: "text-2xl", subtitle: "text-[10px]" },
    large: { name: "text-4xl", subtitle: "text-xs" },
  };

  return (
    <div className="flex flex-col">
      <span className={cn("font-bold tracking-tight", textColor, sizes[size].name)}>
        Scriva
      </span>
      {showSubtitle && (
        <span className={cn("font-semibold uppercase tracking-[0.14em]", subtitleColor, sizes[size].subtitle)}>
          Clinical AI
        </span>
      )}
    </div>
  );
}
