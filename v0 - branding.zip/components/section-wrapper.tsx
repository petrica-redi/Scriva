"use client";

import { useEffect, useRef, useState, ReactNode } from "react";
import { cn } from "@/lib/utils";

interface SectionWrapperProps {
  id?: string;
  children: ReactNode;
  variant?: "default" | "alt" | "dark";
  className?: string;
}

export function SectionWrapper({ 
  id, 
  children, 
  variant = "default",
  className 
}: SectionWrapperProps) {
  const variants = {
    default: "bg-white",
    alt: "bg-[#f8fafc]",
    dark: "bg-[#042f2e] text-white",
  };

  return (
    <section
      id={id}
      className={cn(
        "py-24 md:py-32 relative",
        variants[variant],
        className
      )}
    >
      <div className="max-w-6xl mx-auto px-6 lg:px-10">
        {children}
      </div>
    </section>
  );
}

interface SectionHeaderProps {
  number: string;
  title: string;
  subtitle: string;
  description?: string;
  dark?: boolean;
}

export function SectionHeader({ 
  number, 
  title, 
  subtitle, 
  description,
  dark = false 
}: SectionHeaderProps) {
  return (
    <div className="mb-16">
      <div className={cn(
        "flex items-center gap-3 text-xs font-semibold uppercase tracking-[0.12em] mb-4",
        dark ? "text-[#2dd4bf]" : "text-[#0d9488]"
      )}>
        <span>{number} — {subtitle}</span>
        <div className={cn(
          "flex-1 h-px max-w-20",
          dark ? "bg-white/10" : "bg-slate-200"
        )} />
      </div>
      <h2 
        className={cn(
          "text-4xl md:text-5xl font-extrabold tracking-[-0.03em] leading-[1.1]",
          dark ? "text-white" : "text-slate-900"
        )}
        dangerouslySetInnerHTML={{ __html: title }}
      />
      {description && (
        <p className={cn(
          "mt-5 text-lg leading-relaxed max-w-xl",
          dark ? "text-[#5eead4]" : "text-slate-500"
        )}>
          {description}
        </p>
      )}
    </div>
  );
}

interface RevealProps {
  children: ReactNode;
  delay?: number;
  className?: string;
}

export function Reveal({ children, delay = 0, className }: RevealProps) {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => setIsVisible(true), delay);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.1, rootMargin: "0px 0px -40px 0px" }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [delay]);

  return (
    <div
      ref={ref}
      className={cn(
        "transition-all duration-700 ease-out",
        isVisible 
          ? "opacity-100 translate-y-0" 
          : "opacity-0 translate-y-6",
        className
      )}
    >
      {children}
    </div>
  );
}
